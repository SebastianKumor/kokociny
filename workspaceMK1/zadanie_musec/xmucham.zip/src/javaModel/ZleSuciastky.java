package javaModel;

public class ZleSuciastky extends Suciastky {	
		@Override
		public void setCena(int Cena)
		{
			Cena=(Cena*1);
		}
}