package javaModel;

public class DobreSuciastky extends Suciastky {
	
	@Override
	public void setCena(int Cena)
	{
		Cena=(Cena*2);
	}
}
