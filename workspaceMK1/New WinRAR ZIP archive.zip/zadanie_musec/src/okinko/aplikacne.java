package okinko;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javaModel.*;
import okinko.HlavneOkno;

public class aplikacne extends JFrame{

	public void VizProjektant () {
		
	}
}
