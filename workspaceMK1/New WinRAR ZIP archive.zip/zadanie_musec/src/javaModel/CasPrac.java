package javaModel;

import okinko.HlavneOkno;

public class CasPrac {
public int Cas;
private int predpokladanyCas = 7;

public int getCas() 
{
	return Cas;
}

public void setCas(int Cas) 
{
	this.Cas = Cas;
}







}
